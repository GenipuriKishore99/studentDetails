import { getData, saveData } from "./context";

const url="http://127.0.0.1:5000/studentForm/"

export function saveDataStudent(data){
    return saveData(url,data)
}


export function getDataStudent(){
    return getData(url)
}