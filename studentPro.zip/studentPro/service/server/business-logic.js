var express=require('express');

var cors=require('cors');

var mongoClient=require('mongodb').MongoClient;

var constStr="mongodb://127.0.0.1:27017";




var app=express()
app.use(cors())

app.use(express.urlencoded({
    extended:true
}))

app.use(express.json());

app.get("/studentForm",(req,res)=>{
    mongoClient.connect(constStr).then((obj)=>{
       var database=obj.db("studentDetails")
       database.collection("studentData").find({}).toArray().then((doc)=>{
        res.send(doc)
       }).catch((err)=>{
        console.log(err)
       })
    })
})


app.post("/studentForm",(req,res)=>{
    console.log(req.body)
    var details={
        "Name":req.body.Name,
        "Email":req.body.Email,
        "DateofBirth":req.body.DateofBirth,
        "Password":req.body.Password
    }
    mongoClient.connect(constStr).then((obj)=>{
        var database=obj.db("studentDetails")
        database.collection("studentData").insertOne(details).then((doc)=>{
            res.redirect("/studentForm")
        }).catch((err)=>{
            console.log(err)
        })
    })
})


app.listen(5000)

console.log(`server running:http://127.0.0.1:5000`)