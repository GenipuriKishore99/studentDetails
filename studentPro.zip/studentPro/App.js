import React from 'react'
import { BrowserRouter} from "react-router-dom";
import { Menu } from './menu';
import { AppRouter } from './appRouter';
import { Cookies, CookiesProvider } from 'react-cookie';

const App = () => {
  return (
    <div>
      <CookiesProvider>
      <BrowserRouter>
      <Menu/>
      <AppRouter/>
      </BrowserRouter>
      </CookiesProvider>
    </div>
  )
}

export default App