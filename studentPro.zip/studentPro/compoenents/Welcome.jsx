import React from 'react';
import { useCookies } from "react-cookie";
import { useNavigate } from 'react-router-dom';
import { useEffect } from 'react';
const Welcome = () => {
    const navigate=useNavigate();

    const [cookies,setCookie,removeCookie]=useCookies();
    useEffect(()=>{
        if(cookies.user==undefined){
            navigate("/studentLog")
        }
    },[])
    function deleteCookie(){
        removeCookie("user");
        navigate("/studentLog")
    }

  return (
    <div>Welcome user {cookies.user}
        <button onClick={()=>{deleteCookie()}}>Logout</button>
    </div>
  )
}

export default Welcome