import { useFormik } from "formik"
import { saveDataStudent } from "../services/student-service"
import { useNavigate } from "react-router-dom"

export const StudentForm=()=>{

    const navigate=useNavigate()


    const formik=useFormik({
        initialValues:{
            "Name":"",
            "Email":"",
            "DateofBirth":"",
            "Password":""
        },
        onSubmit:(values)=>{
            saveDataStudent(values).then(()=>{
                alert('data saved....!')
                
               
            })
            navigate("/studentLog")
            window.location.reload();
            
            
            
            // alert(JSON.stringify(values))

        }
        

    })
    return(
        <div>
            <form className="m-3" onSubmit={formik.handleSubmit}>
                <div>
                    <label className="form-label">Name</label>
                    <input type="text" placeholder="Enter Name here.....!" className="form-control" {...formik.getFieldProps('Name')}/>
                </div>
                <div>
                    <label className="form-label">Email</label>
                    <input type="email" placeholder="Enter email here.....!" className="form-control" {...formik.getFieldProps('Email')}/>
                </div>
                <div>
                    <label className="form-label">DateOfBirth</label>
                    <input type="date" className="form-control" {...formik.getFieldProps('DateofBirth')}/>
                </div>
                <div>
                    <label className="form-label">Password</label>
                    <input type="password" placeholder="Enter Name here.....!" className="form-control" {...formik.getFieldProps('Password')}/>
                </div>
                <div className="m-2">
                    <button className="btn btn-primary me-2">Save</button>
                    <button className="btn btn-danger">Cancel</button>
                </div>
            </form>
        </div>
    )

}