import { useFormik } from "formik"
import { getDataStudent } from "../services/student-service"
import { useNavigate } from "react-router-dom";
import {useCookies} from 'react-cookie';
export const StudentLogin=()=>{
    const [cookies,setCookie,removeCookie]=useCookies();

    const navigate=useNavigate()

    const formik=useFormik({
        initialValues:{
            "Email":"",
            "Password":""
        },
        onSubmit:(values)=>{
            getDataStudent(values).then((res)=>{

                for(var students of res.data){
                    
                    if(students.Email===values.Email && students.Password===values.Password){
                        setCookie("user",values.Email)
                        navigate("/studentView")
                        break;
                    }
                    else{
                        navigate("/err")
                    }
                }

            })

        }
    })


    return(
        <div className="m-3">
            <form onSubmit={formik.handleSubmit}>
                <div>
                    <label className="form-label">Email</label>
                    <input type="email"placeholder="Enter Email here..!"className="form-control" name="Email" {...formik.handleChange}/>
                </div>
                <div>
                    <label className="form-label">Password</label>
                    <input type="password"placeholder="Enter Password..!"className="form-control" name="Password" {...formik.handleChange}/>
                </div>
                <div className="m-3">
                    <input type="submit" value="Login" className="btn btn-secondary me-2"/>
                    <input type="submit" value="cancel" className="btn btn-danger"/>
                </div>
            </form>
        </div>
    )
}