import { Link } from "react-router-dom"

export const Error=()=>{
    return(
        <div>
            <Link to="/studentLog">Entered wrong credentials try agin</Link>
        </div>
    )
}