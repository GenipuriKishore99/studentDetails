import { useEffect, useState } from "react";
import { getDataStudent } from "../services/student-service";
import { useNavigate } from "react-router-dom";
import { useCookies } from "react-cookie";

export const StudentView = () => {
  const [studentInfo, setStudentInfo] = useState([]);
  const headers = ["Name", "Email", "DoB", "Password"];
  const navigate=useNavigate();

  useEffect(() => {
    studentData();
  }, []);
  const [cookies, setCookie, removeCookie] = useCookies();
  useEffect(() => {
    if (cookies.user == undefined) {
      navigate("/studentLog");
    }
  }, []);
  function deleteCookie() {
    removeCookie("user");
    navigate("/studentLog");
  }

  const studentData = () => {
    getDataStudent().then((res) => {
      setStudentInfo(res.data);
    });
  };
  return (
    <>
    <div>
        <div>
          Welcome user {cookies.user}
          <button
            onClick={() => {
              deleteCookie();
            }} className="btn btn-warning"
          >
            Logout
          </button>
        </div>
      </div>
    <table className="table  table-bordered table-striped m-2">
      
      <thead>
        {headers.map((h) => {
          return (
            <th>
              <tr>{h}</tr>
            </th>
          );
        })}
      </thead>
      <tbody>
        {studentInfo.map((m) => {
          const { Name, Email, DateofBirth, Password } = m;
          return (
            <tr>
              <td>{Name}</td>
              <td>{Email}</td>
              <td>{DateofBirth}</td>
              <td>{Password}</td>
            </tr>
          );
        })}
      </tbody>
    </table>
    </>
  );
};
