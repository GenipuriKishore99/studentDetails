import { Link } from "react-router-dom"
export const Menu=()=>{
    return(
        <div className="bg-dark text-white p-3 d-flex justify-content-center">
            <Link to="/" className="me-3 text-white text-decoration-none">Home</Link>
            <Link to="/studentReg" className="me-3 text-white text-decoration-none">StudentReg</Link>
            <Link to="/studentLog" className="me-3 text-white text-decoration-none">StudentLogin</Link>
            <Link to="/studentView" className="me-3 text-white text-decoration-none">StudentView</Link>
            
        </div>
    )
}