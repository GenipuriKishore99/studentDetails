import { Home } from "./components/Home"
import { Routes,Route } from "react-router-dom"
import { StudentForm } from "./components/StudentForm"
import { StudentLogin } from "./components/StudentLogin"
import { StudentView } from "./components/StudentView"
import { Error } from "./components/Error"
import Welcome from "./components/Welcome"

export const AppRouter=()=>{
    return(
        <div>
            <Routes>
                <Route path="/" element={<Home/>}></Route>
                <Route path="/studentReg" element={<StudentForm/>}></Route>
                <Route path="/studentLog" element={<StudentLogin/>}></Route>
                <Route path="/studentView" element={<StudentView/>}></Route>
                <Route path="/err" element={<Error/>}></Route>
                <Route path="/wel" element={<Welcome/>}></Route>
            </Routes>
        </div>
    )
}